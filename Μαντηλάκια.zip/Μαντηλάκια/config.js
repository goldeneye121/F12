module.exports = {
  BOT_TOKEN: "7961135875:AAHujaKyTfxfEGJtvzm-d1EN5b388OgBAu8",
  OWNER_ID: ["7456641841"],
};

/*/━━━━━━━━━━━━━━━━━━━━━━  
X V I C T U S - G E T S U Z O
━━━━━━━━━━━━━━━━━━━━━━  

Дев ( 🇷🇺 ) : t.me/Kamilxiter
Каналы : t.me/Comunityxtrix 
THANKS FOR BUYER

⚠️ ПРЕДУПРЕЖДЕНИЕ! ⚠️
📌 Этот бот использует базу данных.
📌 Если ваш токен не зарегистрирован в базе данных,
📌 бот не будет работать!
📌 Убедитесь, что ваш токен зарегистрирован перед использованием бота.

⚠️ **PERINGATAN!** ⚠️  
📌 Bot ini menggunakan database.  
📌 Jika token Anda **tidak terdaftar di database**,  
📌 bot **tidak akan berjalan**!  
📌 Pastikan token Anda sudah terdaftar sebelum menggunakan bot ini.  

━━━━━━━━━━━━━━━━━━━━━━/*/
